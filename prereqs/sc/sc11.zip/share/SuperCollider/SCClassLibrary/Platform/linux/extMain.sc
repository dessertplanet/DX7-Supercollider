+ Main {
	platformClass { ^LinuxPlatform }
}
